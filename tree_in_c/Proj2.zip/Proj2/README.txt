To build and run the project please use the run script.

Run the script from within the Proj2 directory

EX:
cd Proj2
./run
